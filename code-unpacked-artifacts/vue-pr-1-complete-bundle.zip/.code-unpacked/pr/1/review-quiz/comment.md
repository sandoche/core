<!-- code-unpacked:review-quiz -->
## Code Unpacked · review-quiz

20 questions about Vue Vapor · Architectural review exercise, with deterministic scoring and source-linked recommendations.

Source revision: `3a3bd842cad433462697f329c3dceaf274b3847d`

Download and open `index.html` to take the quiz. Answers and explanations appear after submission. The score measures this exercise only; it does not establish review completeness or approval readiness.

<details><summary>Source coverage limitations</summary>

- pnpm-lock.yaml: Lockfile metadata only
- Import context limited to 48 files; 72 omitted

</details>

### Download and open

[Download the complete review-quiz viewer (ZIP)](https://github.com/sandoche/core/raw/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/review-quiz.html.zip). Extract it and open `index.html`; it works offline.

[Browse the committed artifact index](https://github.com/sandoche/core/tree/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts).

Delivery uses committed files in this fork; these links are not browser-uploaded attachments.
