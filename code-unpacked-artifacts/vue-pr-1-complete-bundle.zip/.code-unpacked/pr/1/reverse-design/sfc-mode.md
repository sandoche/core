# SFC mode and backend dispatch

Document family: Sequence diagrams

## Mode propagation

**Observed**

parse records vapor on the descriptor from script/template attributes; a vapor script is setup. compileScript combines descriptor and option mode and forwards it to inline template compilation. Client JS/TS exports are marked so runtime dispatch recognizes the component. Binding metadata is also recorded for type-declared props before expression generation consumes it.

Sources: [`packages/compiler-sfc/src/parse.ts:139–211`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/parse.ts#L139-L211) · [`packages/compiler-sfc/src/compileScript.ts:866–945`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/compileScript.ts#L866-L945) · [`packages/compiler-sfc/src/compileScript.ts:970–1025`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/compileScript.ts#L970-L1025) · [`packages/compiler-sfc/src/script/defineProps.ts:73–100`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/script/defineProps.ts#L73-L100) · [`packages/runtime-vapor/src/apiDefineComponent.ts:1–21`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiDefineComponent.ts#L1-L21)

## SSR remains a separate selection

**Observed**

compileTemplate selects the SSR compiler before considering the Vapor client compiler. Its return helpers are generalized so compileScript can avoid duplicate imports without relying on one AST shape. Inline Vapor output supplies its own return statements. Review TS/JS and inline/non-inline branches together; a marker alone cannot guarantee a matching render program.

Sources: [`packages/compiler-sfc/src/compileTemplate.ts:209–273`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/compileTemplate.ts#L209-L273) · [`packages/compiler-sfc/src/compileScript.ts:866–945`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/compileScript.ts#L866-L945) · [`packages/compiler-sfc/src/compileScript.ts:970–1025`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/compileScript.ts#L970-L1025)

## Compiler selection

Which backend does compileTemplate choose for each mode?

```mermaid
flowchart TD
 O["compileTemplate options"] --> SSR{"ssr?"}
 SSR -->|yes| S["CompilerSSR"]
 SSR -->|no| V{"vapor?"}
 V -->|yes| C["CompilerVapor"]
 V -->|no| D["CompilerDOM"]
```

Sources: [`packages/compiler-sfc/src/compileTemplate.ts:209–273`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/compileTemplate.ts#L209-L273)
