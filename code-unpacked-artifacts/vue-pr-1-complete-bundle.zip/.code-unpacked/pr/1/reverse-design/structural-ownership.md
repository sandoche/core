# Branch and list ownership

Document family: State machines

## Conditional identity and disposal

**Observed**

A DynamicFragment keeps an anchor, current key, nodes and an optional scope. Equal keys return without rebuilding. A changed key stops the previous scope, removes its nodes, creates the next scope and inserts new nodes before the anchor. Fallback rendering uses the same ownership area when the selected block is invalid. The stable anchor is the position; the key is the identity; the scope is the lifetime.

Sources: [`packages/runtime-vapor/src/block.ts:12–78`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L12-L78) · [`packages/runtime-vapor/src/apiCreateIf.ts:10–37`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateIf.ts#L10-L37)

## Keyed list reuse

**Observed**

ForBlock holds DOM nodes, an optional item scope, render key and shallow refs for item/key/index. The runtime distinguishes unkeyed positional reuse from keyed matching. In the unknown keyed region it maps keys to new positions, updates retained blocks, removes missing ones and computes a longest stable subsequence only when movement is detected. Reverse insertion supplies an already-known next anchor.

Sources: [`packages/runtime-vapor/src/apiCreateFor.ts:68–143`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateFor.ts#L68-L143) · [`packages/runtime-vapor/src/apiCreateFor.ts:206–296`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateFor.ts#L206-L296) · [`packages/runtime-vapor/src/apiCreateFor.ts:299–380`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateFor.ts#L299-L380)

## Optimization proof obligations

**Proposed**

Compiler flags encode once/static, component item and only-child information. Component items already own scopes; FAST_REMOVE may clear the parent container. A reviewer should verify the flag producer and consumer together and test emptying/refilling, reordering, duplicate identities and removal while an effect is queued. These are proposed checks, not claims that all such cases are covered.

Sources: [`packages/compiler-vapor/src/transforms/vFor.ts:27–89`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transforms/vFor.ts#L27-L89) · [`packages/compiler-vapor/src/generators/for.ts:1–236`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/for.ts#L1-L236) · [`packages/shared/src/vaporFlags.ts:1–20`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/shared/src/vaporFlags.ts#L1-L20) · [`packages/runtime-vapor/src/apiCreateFor.ts:299–380`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateFor.ts#L299-L380)

## Branch replacement

What survives a branch switch, and what is disposed?

```mermaid
stateDiagram-v2
 [*] --> Empty
 Empty --> Active: render branch in new scope
 Active --> Active: same key keeps nodes and scope
 Active --> Replacing: different key
 Replacing --> Empty: stop old scope and remove old nodes
 Empty --> Active: create next branch before anchor
```

Sources: [`packages/runtime-vapor/src/block.ts:12–78`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L12-L78) · [`packages/runtime-vapor/src/apiCreateIf.ts:10–37`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateIf.ts#L10-L37)

## Keyed list update

How are reused item blocks updated without rebuilding their DOM?

```mermaid
flowchart LR
 S["Normalize source"] --> M["Match render keys"]
 M --> U["Update retained item refs"]
 M --> X["Stop and remove missing blocks"]
 U --> L["Stable subsequence when moved"]
 L --> I["Reverse mount or move with next anchor"]
```

Sources: [`packages/runtime-vapor/src/apiCreateFor.ts:68–143`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateFor.ts#L68-L143) · [`packages/runtime-vapor/src/apiCreateFor.ts:206–296`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateFor.ts#L206-L296) · [`packages/runtime-vapor/src/apiCreateFor.ts:299–380`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateFor.ts#L299-L380)
