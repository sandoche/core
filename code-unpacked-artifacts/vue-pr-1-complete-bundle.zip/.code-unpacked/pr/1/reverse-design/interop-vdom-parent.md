# Vapor component in a VDOM tree

Document family: Sequence diagrams

## Dispatch and identity

**Observed**

The VDOM renderer recognizes __vapor and consults app-context interop. The adapter creates a self-anchor and shallow refs for incoming props/slots, makes the parent current, creates the Vapor instance and mounts it before the anchor. VNode updates preserve instance and anchor while replacing ref values when an update is needed.

Sources: [`packages/runtime-core/src/renderer.ts:1160–1200`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/renderer.ts#L1160-L1200) · [`packages/runtime-vapor/src/vdomInterop.ts:292–304`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L292-L304) · [`packages/runtime-vapor/src/vdomInterop.ts:40–119`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L40-L119)

## Move and unmount

**Observed**

The adapter moves the block and anchor explicitly, and unmounts through Vapor teardown. Vapor slots in VDOM use a special slot VNode, block storage and props ref. Conditional-slot fallback in that direction carries an explicit TODO. Keep component and slot paths separate when tracing ownership.

Sources: [`packages/runtime-vapor/src/vdomInterop.ts:40–119`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L40-L119) · [`packages/runtime-vapor/src/block.ts:106–166`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L106-L166) · [`packages/runtime-vapor/src/component.ts:514–554`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/component.ts#L514-L554)

## Review evidence limits

**Proposed**

The end-to-end page exercises two-way prop/slot changes; the unit file contains seven describe.todo areas and a concrete emit fallthrough test. Proposed further checks should cover conditional slot fallback, root/multi-node movement, removal while updates are queued and missing plugin installation.

Sources: [`packages/runtime-vapor/__tests__/vdomInterop.spec.ts:1–58`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/__tests__/vdomInterop.spec.ts#L1-L58) · [`packages-private/vapor-e2e-test/__tests__/vdomInterop.spec.ts:25–84`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages-private/vapor-e2e-test/__tests__/vdomInterop.spec.ts#L25-L84) · [`packages/runtime-vapor/src/vdomInterop.ts:40–119`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L40-L119)

## VDOM parent to Vapor child

How does a VNode update reach the retained Vapor instance?

```mermaid
sequenceDiagram
 participant R as VDOM renderer
 participant I as Interop adapter
 participant Ref as Shallow props / slots refs
 participant V as Vapor component
 R->>I: mount marked component
 I->>Ref: wrap vnode props and children
 I->>V: create and mount before anchor
 R->>I: update existing vnode
 I->>Ref: replace values
 Ref-->>V: invalidate dependent work
```

Sources: [`packages/runtime-core/src/renderer.ts:1160–1200`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/renderer.ts#L1160-L1200) · [`packages/runtime-vapor/src/vdomInterop.ts:40–119`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L40-L119)
