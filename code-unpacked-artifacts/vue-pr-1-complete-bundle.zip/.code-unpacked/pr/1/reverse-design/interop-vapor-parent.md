# VDOM component in a Vapor block

Document family: Sequence diagrams

## Delegation to the existing renderer

**Observed**

createComponent delegates unmarked children when appContext.vapor is installed. createVDOMComponent creates a VNode and a Vapor wrapper whose getters feed shallow reactive VDOM props, filtered attrs and a slot proxy. The wrapper is a compatibility adapter; the VDOM component still renders through VDOM internals.

Sources: [`packages/runtime-vapor/src/component.ts:136–214`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/component.ts#L136-L214) · [`packages/runtime-vapor/src/vdomInterop.ts:145–217`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L145-L217)

## A fragment is an insertion adapter

**Proposed**

The returned VaporFragment overrides insert and remove. First insert invokes VDOM mount, subsequent insert uses reorder movement, and scope disposal/removal invokes VDOM unmount. VDOM slots inside Vapor use a separate effect that patches a retained VNode or switches to Vapor fallback nodes. Proposed extensions should verify both native component lifetime and fallback lifetime.

Sources: [`packages/runtime-vapor/src/vdomInterop.ts:145–217`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L145-L217) · [`packages/runtime-vapor/src/vdomInterop.ts:219–290`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L219-L290)

## Vapor parent to VDOM child

Which renderer owns a VDOM child mounted through a VaporFragment?

```mermaid
sequenceDiagram
 participant C as Vapor createComponent
 participant A as VDOM adapter fragment
 participant R as VDOM renderer internals
 C->>A: create unmarked child
 A->>R: first insert mounts VNode
 A->>R: later insert moves VNode
 A->>R: remove or scope disposal unmounts
 Note over R: VDOM owns the child render
```

Sources: [`packages/runtime-vapor/src/component.ts:136–214`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/component.ts#L136-L214) · [`packages/runtime-vapor/src/vdomInterop.ts:145–217`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L145-L217)
