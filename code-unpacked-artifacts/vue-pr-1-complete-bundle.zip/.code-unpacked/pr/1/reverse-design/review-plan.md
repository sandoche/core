# Review plan, gaps and extension decisions

Document family: Review plan

## Suggested passes

**Proposed**

1. Establish representation: compiler entry, IR, transforms and block codegen.
2. Trace runtime lifetime: template factories, blocks, renderEffect, scope and scheduler.
3. Review component contracts: props/attrs/emits, slots, refs and lifecycle.
4. Review SFC integration, each interop direction and hydration.
5. Inspect shared runtime/compiler compatibility, exports, build trimming and test configuration.

This order is proposed to reduce context switching. The complete file inventory stays available so architectural grouping does not erase supporting or omitted files.

Sources: [`packages/compiler-vapor/src/compile.ts:33–68`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L33-L68) · [`packages/runtime-vapor/src/block.ts:12–78`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L12-L78) · [`packages/runtime-vapor/src/renderEffect.ts:14–70`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70) · [`packages/runtime-vapor/src/componentProps.ts:28–112`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L28-L112) · [`packages/runtime-vapor/src/vdomInterop.ts:40–119`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L40-L119) · [`packages/runtime-vapor/src/vdomInterop.ts:145–217`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L145-L217) · [`rollup.config.js:1–416`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/rollup.config.js#L1-L416)

## What evidence does and does not show

**Observed**

Generated snapshots support code shape; runtime tests cover selected helper scenarios; e2e tests cover a concrete browser flow. They do not establish exhaustive parity. No Vue suite or benchmark was executed to produce this bundle. Static extraction also leaves dynamic/external calls unresolved. The captured source and source-range citations remain the authority for the explanations.

Sources: [`packages/compiler-vapor/__tests__/compile.spec.ts:224–265`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/__tests__/compile.spec.ts#L224-L265) · [`packages/runtime-vapor/__tests__/renderEffect.spec.ts:36–155`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/__tests__/renderEffect.spec.ts#L36-L155) · [`packages/runtime-vapor/__tests__/vdomInterop.spec.ts:1–58`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/__tests__/vdomInterop.spec.ts#L1-L58) · [`packages-private/vapor-e2e-test/__tests__/vdomInterop.spec.ts:25–84`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages-private/vapor-e2e-test/__tests__/vdomInterop.spec.ts#L25-L84)

## Proposed extension checklist

**Proposed**

For a new directive: transform/IR semantics → generated helper usage → runtime timing/cleanup → SFC metadata when relevant. For a new interop case: both component directions, both slot directions, anchors, native props/attrs/emits, movement and teardown. For a performance change: retain semantic tests and use the private benchmark infrastructure to measure a defined scenario; do not turn its existence into a speed claim.

Sources: [`packages/compiler-vapor/src/compile.ts:76–99`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L76-L99) · [`packages/compiler-vapor/src/generators/operation.ts:30–95`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/operation.ts#L30-L95) · [`packages/runtime-vapor/src/directives/custom.ts:1–35`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/directives/custom.ts#L1-L35) · [`packages/runtime-vapor/src/vdomInterop.ts:40–119`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L40-L119) · [`packages/runtime-vapor/src/vdomInterop.ts:145–217`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L145-L217) · [`rollup.config.js:1–416`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/rollup.config.js#L1-L416)
