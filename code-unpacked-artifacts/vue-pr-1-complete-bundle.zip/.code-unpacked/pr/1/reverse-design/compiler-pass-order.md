# Transform and codegen invariants

Document family: Compiler design

## Entry and exit order

**Observed**

compile combines the base preset with supplied transforms. Entry transforms run in order; exit callbacks run in reverse. Structural transforms create nested blocks and restore the previous template/dynamic/slot state on exit. Review code that mutates context.node with this stack discipline in mind: removal short-circuits later work, while replacement changes what later transforms see.

Sources: [`packages/compiler-vapor/src/compile.ts:76–99`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L76-L99) · [`packages/compiler-vapor/src/transform.ts:208–267`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transform.ts#L208-L267) · [`packages/compiler-vapor/src/transform.ts:100–166`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transform.ts#L100-L166)

## Creation precedes reactive work

**Observed**

genBlockContent emits instantiated templates and DOM navigation variables before ordinary operations and effects. genEffects can group multiple IR effects inside one renderEffect wrapper after processing expressions. Constants, v-once and static binding metadata can move an operation out of reactive work. The invariant is preservation of dependencies and creation order, not an effect per directive.

Sources: [`packages/compiler-vapor/src/generators/block.ts:36–85`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/block.ts#L36-L85) · [`packages/compiler-vapor/src/generators/operation.ts:98–150`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/operation.ts#L98-L150) · [`packages/compiler-vapor/src/transform.ts:100–166`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transform.ts#L100-L166)

## Review cases to retain

**Proposed**

Proposed checks: mixed static/dynamic siblings with a component between them; nested if/for/slot blocks; local aliases shadowing setup names; assignment to refs versus props; a v-once subtree next to reactive text. Pair emitted-code assertions with runtime DOM observations so a plausible snapshot cannot hide an incorrect helper contract.

Sources: [`packages/compiler-vapor/__tests__/compile.spec.ts:224–265`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/__tests__/compile.spec.ts#L224-L265) · [`packages/compiler-vapor/src/generators/expression.ts:120–240`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/expression.ts#L120-L240) · [`packages/compiler-vapor/src/transforms/vIf.ts:28–58`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transforms/vIf.ts#L28-L58) · [`packages/compiler-vapor/src/transforms/vFor.ts:27–89`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transforms/vFor.ts#L27-L89)

## Generated block order

Why are DOM navigation references emitted before insertion operations?

```mermaid
flowchart TD
 F["Instantiate template factories"] --> N["Capture child / next / nthChild references"]
 N --> O["Run creation operations"]
 O --> E["Register renderEffect work"]
 E --> R["Return Block"]
```

Sources: [`packages/compiler-vapor/src/generators/block.ts:36–85`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/block.ts#L36-L85) · [`packages/compiler-vapor/src/generators/template.ts:41–118`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/template.ts#L41-L118) · [`packages/compiler-vapor/src/generators/operation.ts:98–150`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/operation.ts#L98-L150)
