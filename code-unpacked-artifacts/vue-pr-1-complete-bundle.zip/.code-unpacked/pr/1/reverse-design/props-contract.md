# Getter props, attrs and emits boundary

Document family: API contracts

## Reconstructed internal contract

**Observed**

RawProps contains named getter functions and an optional dollar array of dynamic object sources/getter maps. Declared props are lazily read by proxy, with camelized lookup and shared resolvePropValue casting/defaults. Dynamic sources are scanned from last to first for ordinary values. The shapes here are internal compiler/runtime behavior, not a published stable external API guarantee.

Sources: [`packages/runtime-vapor/src/componentProps.ts:28–112`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L28-L112) · [`packages/runtime-vapor/src/componentProps.ts:245–308`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L245-L308) · [`packages/compiler-vapor/src/generators/component.ts:1–434`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/component.ts#L1-L434)

## Attr and event separation

**Observed**

Attrs exclude declared props and emit listeners. Class/style have merging behavior across sources, unlike ordinary last-source resolution. Fallthrough can add parent attrs as a dynamic child source and uses distinct DOM caches. The interop attribute test checks that an emit handler does not also fall through to the native VDOM child and fire twice.

Sources: [`packages/runtime-vapor/src/componentProps.ts:138–242`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L138-L242) · [`packages/runtime-vapor/src/componentProps.ts:310–336`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L310-L336) · [`packages/runtime-vapor/src/component.ts:216–284`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/component.ts#L216-L284) · [`packages/runtime-vapor/src/dom/prop.ts:112–174`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/prop.ts#L112-L174) · [`packages/runtime-vapor/__tests__/vdomInterop.spec.ts:1–58`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/__tests__/vdomInterop.spec.ts#L1-L58)

## Extension checks

**Proposed**

Proposed additions should test camel/kebab naming, missing versus undefined values, default factory context, source precedence, class/style removal and emit-listener filtering. Read the normalization helper and proxy together: changing only compiler object generation can violate runtime assumptions about getters and source ordering.

Sources: [`packages/runtime-vapor/src/componentProps.ts:28–112`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L28-L112) · [`packages/runtime-vapor/src/componentProps.ts:245–308`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L245-L308) · [`packages/runtime-vapor/src/componentProps.ts:310–336`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L310-L336) · [`packages/runtime-vapor/src/componentEmits.ts:1–53`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentEmits.ts#L1-L53)

## Raw props routing

Which values become props, attrs or emit handlers?

```mermaid
flowchart TD
 R["Raw getters and dynamic sources"] --> P["Declared prop proxy"]
 R --> A["Attr proxy"]
 R --> E["Emit handler resolution"]
 P --> D["Cast and default resolution"]
 A --> F["Filter declared props and emit listeners"]
 F --> DOM["Single-root fallthrough DOM work"]
```

Sources: [`packages/runtime-vapor/src/componentProps.ts:28–112`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L28-L112) · [`packages/runtime-vapor/src/componentProps.ts:138–242`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L138-L242) · [`packages/runtime-vapor/src/componentProps.ts:245–308`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentProps.ts#L245-L308) · [`packages/runtime-vapor/src/componentEmits.ts:1–53`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentEmits.ts#L1-L53) · [`packages/runtime-vapor/src/component.ts:216–284`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/component.ts#L216-L284)
