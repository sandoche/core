<!-- code-unpacked:reverse-design -->
## Code Unpacked · reverse-design

Vue Vapor · Architecture and review documents

Source revision: `3a3bd842cad433462697f329c3dceaf274b3847d`

The full inline explanation exceeds the comment budget. Complete documents, diagrams, and source coverage are preserved in the HTML attachment (extract the ZIP first when supplied).

<details><summary>Source coverage limitations</summary>

- pnpm-lock.yaml: Lockfile metadata only
- Import context limited to 48 files; 72 omitted

2 of 2 source limitations shown. The complete list is retained in the artifact manifest and HTML.

</details>

### Download and open

[Download the complete reverse-design viewer (ZIP)](https://github.com/sandoche/core/raw/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/reverse-design.html.zip). Extract it and open `index.html`; it works offline.

[Browse the committed artifact index](https://github.com/sandoche/core/tree/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts).

Delivery uses committed files in this fork; these links are not browser-uploaded attachments.
