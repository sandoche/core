# The compiler/runtime boundary

Document family: C4 architecture

## Purpose and review path

**Observed**

This snapshot adds a parallel client compilation path: shared template parsing feeds a Vapor IR and DOM-oriented code generation. The generated program creates real DOM blocks and registers reactive work with runtime-vapor. Existing VDOM rendering remains a separate path.

Review the IR before individual directives, then cross the generated-helper boundary into the runtime. Finally inspect shared runtime-core/runtime-dom changes for assumptions about renderer-specific fields.

Sources: [`packages/compiler-vapor/src/compile.ts:33–68`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L33-L68) · [`packages/compiler-vapor/src/ir/index.ts:1–110`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/ir/index.ts#L1-L110) · [`packages/compiler-vapor/src/generators/block.ts:36–85`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/block.ts#L36-L85) · [`packages/runtime-vapor/src/renderEffect.ts:14–70`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70) · [`packages/runtime-core/src/renderer.ts:1160–1200`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/renderer.ts#L1160-L1200)

## The representation is the contract

**Observed**

Static HTML, dynamic references, operations, effects and return nodes are separate IR concerns. A static template index names a factory; a dynamic node ID names a generated variable. The generated child traversal depends on which IR children are absent from the template. Those identities must remain consistent when a transform wraps, removes or inserts a node.

Sources: [`packages/compiler-vapor/src/ir/index.ts:1–110`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/ir/index.ts#L1-L110) · [`packages/compiler-vapor/src/ir/index.ts:239–268`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/ir/index.ts#L239-L268) · [`packages/compiler-vapor/src/transforms/transformChildren.ts:60–111`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transforms/transformChildren.ts#L60-L111) · [`packages/compiler-vapor/src/generators/template.ts:41–118`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/template.ts#L41-L118)

## Where to extend

**Proposed**

Proposed feature path: add or override a transform, define typed IR if existing operations cannot express the behavior, dispatch it in genOperation, expose the runtime helper and test its lifetime. An expression-only feature may belong entirely in expression codegen; a new runtime abstraction is unnecessary when the existing Block contract suffices.

Sources: [`packages/compiler-vapor/src/compile.ts:33–68`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L33-L68) · [`packages/compiler-vapor/src/compile.ts:76–99`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L76-L99) · [`packages/compiler-vapor/src/generators/operation.ts:30–95`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/operation.ts#L30-L95) · [`packages/compiler-vapor/src/generators/expression.ts:120–240`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/expression.ts#L120-L240) · [`packages/runtime-vapor/src/block.ts:106–166`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L106-L166)

## Template to DOM program

Where does shared parsing end and the new backend begin?

```mermaid
flowchart LR
 SFC["SFC client mode"] --> P["compiler-dom parser"]
 P --> T["Vapor transforms"]
 T --> IR["Vapor IR"]
 IR --> G["Vapor generators"]
 G --> JS["DOM program"]
 JS --> RV["runtime-vapor Blocks and effects"]
 RV --> DOM["DOM"]
 RV --> RC["Shared scheduler and instance APIs"]
```

Sources: [`packages/compiler-vapor/src/compile.ts:33–68`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L33-L68) · [`packages/compiler-sfc/src/compileTemplate.ts:209–273`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-sfc/src/compileTemplate.ts#L209-L273) · [`packages/compiler-vapor/src/generators/block.ts:36–85`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/block.ts#L36-L85) · [`packages/runtime-vapor/src/renderEffect.ts:14–70`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70)
