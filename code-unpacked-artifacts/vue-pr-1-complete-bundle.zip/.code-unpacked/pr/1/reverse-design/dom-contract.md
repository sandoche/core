# DOM helpers and event pathways

Document family: API contracts

## Conversions belong at specific layers

**Observed**

setText expects an already converted string, whereas setElementText converts unknown values. setHtml assigns innerHTML directly; neither that helper nor the generated operation is evidence of a sanitizer. Property setters handle nullish coercion and failures; attribute setters remove nullish values. Review the helper selected by the generator with these preconditions.

Sources: [`packages/runtime-vapor/src/dom/prop.ts:176–204`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/prop.ts#L176-L204) · [`packages/runtime-vapor/src/dom/prop.ts:37–110`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/prop.ts#L37-L110) · [`packages/compiler-vapor/src/generators/prop.ts:1–225`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/prop.ts#L1-L225)

## Reconcile removed keys and registrations

**Observed**

Dynamic prop updates merge sources, clear keys missing from the next object and then set current values. Event values use the effect-cleanup listener route. Delegated events instead store node handlers and share a document listener. The delegated handler walks composed-path/ancestor nodes and observes cancelBubble. These mechanisms have distinct cleanup/replacement assumptions.

Sources: [`packages/runtime-vapor/src/dom/prop.ts:206–261`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/prop.ts#L206-L261) · [`packages/runtime-vapor/src/dom/event.ts:4–44`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/event.ts#L4-L44) · [`packages/runtime-vapor/src/dom/event.ts:50–109`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/event.ts#L50-L109) · [`packages/compiler-vapor/src/generators/event.ts:1–193`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/event.ts#L1-L193)

## Known seams to inspect

**Proposed**

The dynamic setter hardcodes isSVG=false and marks checkbox handling TODO. Proposed review checks should cover specialized versus dynamic setters, dot/caret overrides, SVG, form values, event modifiers and attribute fallthrough. These are focused source-grounded concerns; no broader security or browser-support guarantee is inferred.

Sources: [`packages/runtime-vapor/src/dom/prop.ts:206–261`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/prop.ts#L206-L261) · [`packages/runtime-vapor/src/dom/prop.ts:112–174`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/prop.ts#L112-L174) · [`packages/compiler-vapor/src/transforms/vModel.ts:73–163`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transforms/vModel.ts#L73-L163)
