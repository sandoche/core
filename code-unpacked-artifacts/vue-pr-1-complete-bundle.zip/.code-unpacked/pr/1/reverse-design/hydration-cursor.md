# Hydration cursor and fragment anchors

Document family: State machines

## Adopt rather than clone

**Observed**

The SSR-app entry runs create/mount within withHydration. Factories adopt currentHydrationNode, and direct node insertion is skipped. Initial insertion state points at the first child; later helpers derive the cursor from parent/anchor state. This couples generated static shape to server DOM identity.

Sources: [`packages/runtime-vapor/src/apiCreateApp.ts:28–75`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateApp.ts#L28-L75) · [`packages/runtime-vapor/src/dom/hydration.ts:19–75`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/hydration.ts#L19-L75) · [`packages/runtime-vapor/src/dom/template.ts:7–30`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/template.ts#L7-L30) · [`packages/runtime-vapor/src/block.ts:106–166`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L106-L166)

## Fragment matching and limitations

**Proposed**

Cursor location can search backward from a closing fragment comment and cache its opening partner. Adoption skips comments when needed, performs limited dev shape checks and advances to the next node. Mismatches warn, with explicit TODO recovery/diagnostic work. Proposed review should test nested empty fragments, wrong shape, missing nodes and state restoration after errors.

Sources: [`packages/runtime-vapor/src/dom/hydration.ts:19–75`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/hydration.ts#L19-L75) · [`packages/runtime-vapor/src/dom/hydration.ts:78–129`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/hydration.ts#L78-L129)

## Hydration adoption flow

How does the factory switch from cloning to adopting an existing node?

```mermaid
flowchart LR
 A["createVaporSSRApp"] --> H["withHydration"]
 H --> L["Locate cursor from insertion state"]
 L --> T["template factory"]
 T --> N["Adopt existing node"]
 N --> C["Advance cursor"]
 C --> B["Mount block without direct reinsertion"]
```

Sources: [`packages/runtime-vapor/src/apiCreateApp.ts:28–75`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateApp.ts#L28-L75) · [`packages/runtime-vapor/src/dom/hydration.ts:19–75`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/hydration.ts#L19-L75) · [`packages/runtime-vapor/src/dom/hydration.ts:78–129`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/hydration.ts#L78-L129) · [`packages/runtime-vapor/src/dom/template.ts:7–30`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/dom/template.ts#L7-L30) · [`packages/runtime-vapor/src/block.ts:106–166`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L106-L166)
