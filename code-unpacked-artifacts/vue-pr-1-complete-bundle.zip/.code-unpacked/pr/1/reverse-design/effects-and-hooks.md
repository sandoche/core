# Effects, scheduler and lifecycle timing

Document family: Sequence diagrams

## Observed scheduling

**Observed**

renderEffect runs immediately to collect dependencies and create initial DOM state. On trigger it queues a dirty-checked job through the shared scheduler, attaching instance UID for ordering/diagnostics. The tests show synchronous initial state and asynchronous mutation visibility after nextTick. The wrapper captures current instance and scope for later runs.

Sources: [`packages/runtime-vapor/src/renderEffect.ts:14–70`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70) · [`packages/runtime-core/src/scheduler.ts:91–134`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/scheduler.ts#L91-L134) · [`packages/runtime-vapor/__tests__/renderEffect.spec.ts:36–155`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/__tests__/renderEffect.spec.ts#L36-L155) · [`packages/runtime-vapor/__tests__/renderEffect.spec.ts:221–245`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/__tests__/renderEffect.spec.ts#L221-L245)

## Hook grouping and app mount

**Observed**

A mounted instance with update hooks uses isUpdating to gate beforeUpdate and queue updated for the cycle; internal noLifecycle work bypasses that wrapper. Component mount invokes beforeMount before insertion, then queues mounted. createVaporApp calls flushOnAppMount after mounting. Teardown stops the instance scope before queued unmounted hooks.

Sources: [`packages/runtime-vapor/src/renderEffect.ts:14–70`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70) · [`packages/runtime-vapor/src/component.ts:514–554`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/component.ts#L514-L554) · [`packages/runtime-vapor/src/apiCreateApp.ts:28–75`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateApp.ts#L28-L75) · [`packages/runtime-core/src/scheduler.ts:180–233`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/scheduler.ts#L180-L233)

## Ambient state and open checks

**Proposed**

EffectScope on/off now counts nested activation, and the generic instance helpers support both renderer kinds. Proposed review should cover error exits and nested component/branch work, verifying both active scope and current instance restoration. renderEffect explicitly leaves recurse handling TODO; do not infer recursion parity from use of the shared scheduler.

Sources: [`packages/reactivity/src/effectScope.ts:95–165`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/reactivity/src/effectScope.ts#L95-L165) · [`packages/runtime-core/src/componentCurrentInstance.ts:77–107`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/componentCurrentInstance.ts#L77-L107) · [`packages/runtime-core/src/componentCurrentInstance.ts:11–22`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/componentCurrentInstance.ts#L11-L22) · [`packages/runtime-vapor/src/renderEffect.ts:14–70`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70)

## Reactive update timing

What runs immediately, and what runs after a mutation is queued?

```mermaid
sequenceDiagram
 participant Setup
 participant RE as renderEffect
 participant FX as ReactiveEffect
 participant Q as Shared scheduler
 participant DOM
 Setup->>RE: register fn
 RE->>FX: create and run
 FX->>DOM: initial operations
 Note over FX: dependency changes later
 FX->>Q: queue job
 Q->>FX: run if dirty
 FX->>DOM: update operations
 Q-->>Setup: post flush hooks
```

Sources: [`packages/runtime-vapor/src/renderEffect.ts:14–70`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70) · [`packages/runtime-core/src/scheduler.ts:91–134`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-core/src/scheduler.ts#L91-L134) · [`packages/runtime-vapor/__tests__/renderEffect.spec.ts:36–155`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/__tests__/renderEffect.spec.ts#L36-L155)
