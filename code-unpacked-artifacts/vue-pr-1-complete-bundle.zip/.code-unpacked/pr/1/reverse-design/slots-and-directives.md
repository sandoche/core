# Slots, refs and directive lifetimes

Document family: API contracts

## Slot resolution and fallback

**Observed**

RawSlots provides static BlockFn entries and optional dynamic sources. createSlot uses raw-props proxy semantics for slot props, caches a bound function on a resolved slot, and uses DynamicFragment for replacement/fallback. Dynamic slot names or sources install a renderEffect; static selection can run once. Stable identity prevents a slot from being reconstructed for an unchanged selection.

Sources: [`packages/runtime-vapor/src/componentSlots.ts:62–159`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/componentSlots.ts#L62-L159) · [`packages/runtime-vapor/src/block.ts:12–78`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L12-L78)

## Template refs are post-flush resources

**Observed**

createTemplateRefSetter captures its owner. Dynamic refs unset the prior string/ref, then schedule the new value; v-for values collect in arrays. Scope disposal clears values or removes an item. Function refs are invoked through error handling. The source flags repeated scope-disposal registration for dynamic refs as TODO, so lifetime review is warranted.

Sources: [`packages/runtime-vapor/src/apiTemplateRef.ts:35–145`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiTemplateRef.ts#L35-L145)

## Vapor custom directives

**Proposed**

A custom Vapor directive is a function receiving node, value getter, argument and modifiers; a returned function becomes scope cleanup. Model helpers reuse runtime-dom initialization/update logic and own reactive reads. Proposed extensions should define the cleanup contract explicitly and test it under conditional replacement and list removal.

Sources: [`packages/runtime-vapor/src/directives/custom.ts:1–35`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/directives/custom.ts#L1-L35) · [`packages/runtime-vapor/src/directives/vModel.ts:1–113`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/directives/vModel.ts#L1-L113) · [`packages/runtime-vapor/src/directives/vShow.ts:1–56`](https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/directives/vShow.ts#L1-L56)
