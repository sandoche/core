<!-- code-unpacked:walkthrough -->
## Code Unpacked · walkthrough

A guided architecture review with 12 deep dives, source excerpts, ownership invariants and explicit gaps.

Source revision: `3a3bd842cad433462697f329c3dceaf274b3847d`

13 chapters and 42 source-linked steps. Open the HTML locally to navigate the overview and deep dives, or play the walkthrough.

<details><summary>Source coverage limitations</summary>

- pnpm-lock.yaml: Lockfile metadata only
- Import context limited to 48 files; 72 omitted

</details>

### Download and open

[Download the complete walkthrough viewer (ZIP)](https://github.com/sandoche/core/raw/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/walkthrough.html.zip). Extract it and open `index.html`; it works offline.

[Browse the committed artifact index](https://github.com/sandoche/core/tree/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts).

Delivery uses committed files in this fork; these links are not browser-uploaded attachments.
