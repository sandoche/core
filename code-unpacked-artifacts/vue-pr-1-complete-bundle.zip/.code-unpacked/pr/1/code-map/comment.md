<!-- code-unpacked:code-map -->
## Code Unpacked · code-map

Explore all 303 changed paths, contextual neighbors, compiler/runtime topics and six review flows. Relationship lines are conservative static evidence; dynamic dispatch and unresolved calls remain explicit gaps.

Source revision: `3a3bd842cad433462697f329c3dceaf274b3847d`

357 file cards · 2088 symbols · 2962 source-backed relationships.

Includes file/function exploration, callers and callees, topic/flow filters, syntax highlighting, and source gaps.

The complete large HTML is packaged in the lossless ZIP linked below.

<details><summary>Source coverage limitations</summary>

- pnpm-lock.yaml: Lockfile metadata only
- Import context limited to 48 files; 72 omitted

</details>

### Download and open

[Download the complete code-map viewer (ZIP)](https://github.com/sandoche/core/raw/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/code-map.html.zip). Extract it and open `index.html`; it works offline.

[Browse the committed artifact index](https://github.com/sandoche/core/tree/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts).

Delivery uses committed files in this fork; these links are not browser-uploaded attachments.
