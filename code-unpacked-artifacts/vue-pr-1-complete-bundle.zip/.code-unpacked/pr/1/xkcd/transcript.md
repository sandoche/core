# Vue Vapor · Three source-backed code comics

Three distinct architectural lessons: compile to a DOM plan, dispose branch scopes, and preserve renderer ownership across two adapter directions.

Source revision: 3a3bd842cad433462697f329c3dceaf274b3847d

## The Plan Is Not the Tree

### Panel 1

Scene: A stick figure named compile() holds a sheet marked Template AST. Beside it is a small tree. Clean white background.

compile(): I brought a template AST.

Start with shared parsing.

Evidence: packages/compiler-vapor/src/compile.ts:33-68 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/compile.ts#L33-L68)

### Panel 2

Scene: RootIRNode, a stick figure with a blueprint labeled Templates | Operations | Effects, points toward a drafting table. Do not draw virtual nodes.

RootIRNode: First, a plan for DOM work.

Transform builds Vapor IR.

Evidence: packages/compiler-vapor/src/ir/index.ts:1-110 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/ir/index.ts#L1-L110); packages/compiler-vapor/src/transform.ts:100-166 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/transform.ts#L100-L166)

### Panel 3

Scene: renderEffect() stands beside a real-looking simple DOM element box labeled DOM, holding a tiny wrench. compile() looks at the blueprint approvingly.

renderEffect(): Then run the operations.

Generate helpers, then update DOM.

Evidence: packages/compiler-vapor/src/generate.ts:101-160 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generate.ts#L101-L160); packages/compiler-vapor/src/generators/operation.ts:98-150 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/compiler-vapor/src/generators/operation.ts#L98-L150); packages/runtime-vapor/src/renderEffect.ts:14-70 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/renderEffect.ts#L14-L70)

Limitation: The metaphor covers the client Vapor pipeline only. Static templates, expressions and structural helpers have additional detail; SSR backend selection is separate.

## Please Take Your Subscriptions

### Panel 1

Scene: DynamicFragment holds a door open beside a small permanent peg labeled anchor. EffectScope carries a box labeled old branch effects.

DynamicFragment: New branch. Same anchor.

A changed key replaces the branch.

Evidence: packages/runtime-vapor/src/block.ts:12-78 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L12-L78)

### Panel 2

Scene: EffectScope carries the box away. The old branch is represented by one empty dotted outline; avoid ghosts still working.

EffectScope: Old scope stopped.

Stop subscriptions before replacement.

Evidence: packages/runtime-vapor/src/block.ts:12-78 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L12-L78); packages/reactivity/src/effectScope.ts:95-165 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/reactivity/src/effectScope.ts#L95-L165)

### Panel 3

Scene: DynamicFragment welcomes a fresh stick figure and new box labeled new branch effects beside the unchanged anchor peg.

DynamicFragment: Fresh scope. Fresh nodes.

Equal key? Keep the current branch.

Evidence: packages/runtime-vapor/src/block.ts:12-78 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/block.ts#L12-L78); packages/runtime-vapor/src/apiCreateIf.ts:10-37 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/apiCreateIf.ts#L10-L37)

Limitation: This depicts DynamicFragment branch replacement. Equal keys retain the existing branch; list items and components have related but distinct ownership paths.

## Two Doors, Two Owners

### Panel 1

Scene: vaporInteropPlugin, a stick figure at a reception desk labeled app context, points to two clearly separate doors labeled Vapor in VDOM and VDOM in Vapor.

vaporInteropPlugin: We need both directions.

Install the interop plugin.

Evidence: packages/runtime-vapor/src/vdomInterop.ts:292-304 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L292-L304)

### Panel 2

Scene: Through the Vapor in VDOM door, renderEffect() works beside a simple DOM block and a peg labeled anchor. A small envelope is labeled props ref.

renderEffect(): Keep my instance. Update refs.

VDOM parent, Vapor child.

Evidence: packages/runtime-vapor/src/vdomInterop.ts:40-119 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L40-L119)

### Panel 3

Scene: Through the VDOM in Vapor door, createVDOMComponent() hands a work order labeled mount / move / unmount to a desk labeled VDOM renderer.

createVDOMComponent(): The native renderer owns this child.

A fragment delegates the work.

Evidence: packages/runtime-vapor/src/vdomInterop.ts:145-217 (https://github.com/sandoche/core/blob/3a3bd842cad433462697f329c3dceaf274b3847d/packages/runtime-vapor/src/vdomInterop.ts#L145-L217)

Limitation: The adapters do not establish complete renderer parity. Conditional slot fallback and several interop unit areas remain TODO in this snapshot.
