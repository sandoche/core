<!-- code-unpacked:xkcd -->
## Code Unpacked · xkcd

Vue Vapor · Three source-backed code comics: Three distinct architectural lessons: compile to a DOM plan, dispose branch scopes, and preserve renderer ownership across two adapter directions.

Source revision: `3a3bd842cad433462697f329c3dceaf274b3847d`

**The Plan Is Not the Tree** — The metaphor covers the client Vapor pipeline only. Static templates, expressions and structural helpers have additional detail; SSR backend selection is separate.

**Please Take Your Subscriptions** — This depicts DynamicFragment branch replacement. Equal keys retain the existing branch; list items and components have related but distinct ownership paths.

**Two Doors, Two Owners** — The adapters do not establish complete renderer parity. Conditional slot fallback and several interop unit areas remain TODO in this snapshot.

The generated images include the full explanation. Source-backed accessible transcripts are available in the HTML and transcript.md.

<details><summary>Source coverage limitations</summary>

- pnpm-lock.yaml: Lockfile metadata only
- Import context limited to 48 files; 72 omitted

</details>

### Download and open

[Download the complete xkcd viewer (ZIP)](https://github.com/sandoche/core/raw/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/xkcd.html.zip). Extract it and open `index.html`; it works offline.

[Browse the committed artifact index](https://github.com/sandoche/core/tree/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts).

![xkcd comic-01.png](https://raw.githubusercontent.com/sandoche/core/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/comic-01.png)

![xkcd comic-02.png](https://raw.githubusercontent.com/sandoche/core/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/comic-02.png)

![xkcd comic-03.png](https://raw.githubusercontent.com/sandoche/core/0da36b0a452a16ab72a127f0bf6c00db29954e7e/code-unpacked-artifacts/comic-03.png)

Delivery uses committed files in this fork; these links are not browser-uploaded attachments.
